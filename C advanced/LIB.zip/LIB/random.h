#ifndef _RANDOM_
#define _RAMDOM_

#include <stdlib.h>
#include <string.h>
#include <time.h>

char *randString(int length);
char *randPhoneNumber(int length);
