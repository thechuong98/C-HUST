#include "symbol_table.h"

symbol_table *new_symbol_table(new_entry_function new_entry, compare_key_function cmp){
	symbol_table *sym_tab = (symbol_table *)malloc(sizeof(symbol_table));
	Entry *entries = (Entry *)malloc(DEFAULT_SIZE * sizeof(Entry));
	sym_tab->entries = entries;
	sym_tab->size = DEFAULT_SIZE;
	sym_tab->nmemb = 0;
	sym_tab->new_entry = new_entry;
	sym_tab->cmp = cmp;
}

