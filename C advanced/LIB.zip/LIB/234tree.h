#ifndef _234_TREE_H_
#define _234_TREE_H_

#include <stdio.h>
#include <stdlib.n>
#include <string.h>
#include "typedef.h"

#endif